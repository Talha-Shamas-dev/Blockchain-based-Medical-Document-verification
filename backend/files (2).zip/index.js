import 'dotenv/config'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

const req  = (k) => { const v = process.env[k]; if (!v?.trim()) throw new Error(`[Config] Missing required: ${k}`); return v.trim() }
const opt  = (k, d = '') => (process.env[k] || '').trim() || d
const int  = (k, d)      => { const v = parseInt(process.env[k], 10); return Number.isFinite(v) ? v : d }
const bool = (k, d=false)=> { const v = process.env[k]; return v === undefined ? d : v.toLowerCase() === 'true' || v === '1' }

export const config = {
  server: {
    port:   int('PORT', 4000),
    env:    opt('NODE_ENV', 'development'),
    isProd: opt('NODE_ENV', 'development') === 'production',
  },

  fabric: {
    // ── Updated to match your actual deployment ──────────────────────
    channel:         opt('FABRIC_CHANNEL',          'mychannel'),   // ✓ your channel
    chaincode:       opt('FABRIC_CHAINCODE',         'medical'),    // ✓ your CC name
    mspId:           opt('FABRIC_MSP_ID',            'Org1MSP'),
    peerAddr:        opt('FABRIC_PEER_ADDR',         'localhost:7051'),
    ordererAddr:     opt('FABRIC_ORDERER_ADDR',      'localhost:7050'),
    ordererHostname: opt('FABRIC_ORDERER_HOSTNAME',  'orderer.example.com'),

    // Your path: /home/blockchain/fabric/fabric-samples/test-network/organizations
    orgPath:         opt('FABRIC_ORG_PATH',
      '/home/blockchain/fabric/fabric-samples/test-network/organizations'),

    orgDomain: opt('FABRIC_ORG_DOMAIN', 'org1.example.com'),
    user:      opt('FABRIC_USER',       'Admin'),   // ✓ you used Admin@org1.example.com

    connectTimeout: int('FABRIC_CONNECT_TIMEOUT_MS', 5000),
    txTimeout:      int('FABRIC_TX_TIMEOUT_MS', 30000),
    maxRetries:     int('FABRIC_MAX_RETRIES', 3),
  },

  redis: {
    host:      opt('REDIS_HOST', '127.0.0.1'),
    port:      int('REDIS_PORT', 6379),
    password:  opt('REDIS_PASSWORD'),
    db:        int('REDIS_DB', 0),
    keyPrefix: opt('REDIS_KEY_PREFIX', 'medical:'),
    ttl: {
      record:         int('CACHE_TTL_RECORD', 60),
      patientRecords: int('CACHE_TTL_PATIENT_RECORDS', 30),
      history:        int('CACHE_TTL_HISTORY', 300),
    },
  },

  jwt: {
    secret:         req('JWT_SECRET'),
    expiresIn:      opt('JWT_EXPIRES_IN', '8h'),
    refreshExpires: opt('JWT_REFRESH_EXPIRES_IN', '7d'),
  },

  ipfs: {
    apiKey:  opt('PINATA_API_KEY'),
    secret:  opt('PINATA_SECRET'),
    gateway: opt('IPFS_GATEWAY', 'https://gateway.pinata.cloud/ipfs'),
  },

  encryption: {
    key: opt('ENCRYPTION_KEY', '0'.repeat(64)),
  },

  rateLimit: {
    windowMs:     int('RATE_LIMIT_WINDOW_MS', 60_000),
    maxRequests:  int('RATE_LIMIT_MAX_REQUESTS', 100),
    insuranceMax: int('RATE_LIMIT_INSURANCE_MAX', 50),
  },

  cors: {
    origin: opt('CORS_ORIGIN', 'http://localhost:3000'),
  },

  queue: {
    txConcurrency:   int('QUEUE_TX_CONCURRENCY', 5),
    ipfsConcurrency: int('QUEUE_IPFS_CONCURRENCY', 3),
    retryAttempts:   int('QUEUE_RETRY_ATTEMPTS', 3),
    retryDelay:      int('QUEUE_RETRY_DELAY_MS', 2000),
  },
}

export default config
