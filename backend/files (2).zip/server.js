/**
 * MedChain Backend — server.js  v2.1
 * ─────────────────────────────────────────────────────────────────────────────
 * Updated to match YOUR actual Hyperledger Fabric deployment:
 *   Channel   : mychannel
 *   Chaincode : medical
 *   Org Path  : /home/blockchain/fabric/fabric-samples/test-network/organizations
 *   User      : Admin@org1.example.com
 *
 * Start:  node --env-file=.env server.js
 * Dev:    node --watch --env-file=.env server.js
 *
 * Startup order:
 *   1. Validate config (throws on missing required env vars)
 *   2. Create Express + HTTP server
 *   3. Attach Socket.IO to HTTP server
 *   4. Register all middleware and routes
 *   5. Pre-connect to Fabric (non-blocking)
 *   6. Start BullMQ workers
 *   7. Start listening
 *   8. Register graceful shutdown handlers
 */

import 'dotenv/config'
import http        from 'http'
import express     from 'express'
import helmet      from 'helmet'
import cors        from 'cors'
import compression from 'compression'
import morgan      from 'morgan'

// Config — validated at import time (throws if JWT_SECRET missing etc.)
import { config } from './src/config/index.js'

// Utils
import logger, { httpLogger } from './src/utils/logger.js'

// Services
import fabricService       from './src/services/fabric.service.js'
import cacheService        from './src/services/cache.service.js'
import ipfsService         from './src/services/ipfs.service.js'
import notificationService from './src/services/notification.service.js'
import { startWorkers, stopWorkers } from './src/services/queue.service.js'

// Middleware
import { errorHandler, notFound } from './src/middleware/errorHandler.js'
import { generalLimiter }         from './src/middleware/rateLimiter.js'

// Routes
import recordsRouter from './src/routes/records.routes.js'
import verifyRouter  from './src/routes/verify.routes.js'
import ipfsRouter    from './src/routes/ipfs.routes.js'
import authRouter    from './src/routes/auth.routes.js'
import healthRouter  from './src/routes/health.routes.js'
import { accessRouter } from './src/routes/access.routes.js'

// ─────────────────────────────────────────────────────────────────────────────
// Express + HTTP server
// ─────────────────────────────────────────────────────────────────────────────

const app    = express()
const server = http.createServer(app)

// Security headers
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }))

// CORS
app.use(cors({
  origin:         config.cors.origin,
  methods:        ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials:    true,
  maxAge:         600,
}))

// Body parsing + compression
app.use(express.json({ limit: '2mb' }))
app.use(express.urlencoded({ extended: true, limit: '2mb' }))
app.use(compression())

// Request ID — for log correlation across async calls
app.use((req, _res, next) => {
  req.id = crypto.randomUUID()
  next()
})

// HTTP logging
if (config.server.isProd) {
  app.use(morgan('combined', { stream: { write: m => logger.info(m.trim()) } }))
} else {
  app.use(morgan('dev'))
}
app.use(httpLogger)

// Trust proxy (if behind Nginx)
app.set('trust proxy', 1)

// Global rate limit on all /api routes
app.use('/api/', generalLimiter)

// ─────────────────────────────────────────────────────────────────────────────
// Routes
// ─────────────────────────────────────────────────────────────────────────────

app.use('/api/health',  healthRouter)
app.use('/api/auth',    authRouter)
app.use('/api/records', recordsRouter)
app.use('/api/access',  accessRouter)
app.use('/api/verify',  verifyRouter)
app.use('/api/ipfs',    ipfsRouter)

// Catch-all 404 + global error handler (must be AFTER routes)
app.use(notFound)
app.use(errorHandler)

// ─────────────────────────────────────────────────────────────────────────────
// Boot
// ─────────────────────────────────────────────────────────────────────────────

async function boot() {
  logger.info('═══════════════════════════════════════════════')
  logger.info('  MedChain Backend  v2.1')
  logger.info(`  Env       : ${config.server.env}`)
  logger.info(`  Port      : ${config.server.port}`)
  logger.info(`  Channel   : ${config.fabric.channel}`)
  logger.info(`  Chaincode : ${config.fabric.chaincode}`)
  logger.info(`  Peer      : ${config.fabric.peerAddr}`)
  logger.info(`  User      : ${config.fabric.user}@${config.fabric.orgDomain}`)
  logger.info(`  Org Path  : ${config.fabric.orgPath}`)
  logger.info('═══════════════════════════════════════════════')

  // 1. Attach WebSocket (Socket.IO) — must be before listen()
  notificationService.attach(server)

  // 2. Pre-connect to Fabric — non-blocking, workers retry on first job
  fabricService.connect().catch(err =>
    logger.warn('[Boot] Fabric pre-connect failed — will retry on first transaction', {
      error: err.message,
      tip: 'Make sure test-network is running: ./network.sh up',
    })
  )

  // 3. Start BullMQ workers — they process the async transaction queue
  startWorkers(fabricService, ipfsService, notificationService, cacheService)

  // 4. Start HTTP server
  server.listen(config.server.port, () => {
    logger.info(`[Boot] HTTP  → http://localhost:${config.server.port}`)
    logger.info(`[Boot] WS   → ws://localhost:${config.server.port}/ws`)
    logger.info('[Boot] Ready ✓')
  })
}

// ─────────────────────────────────────────────────────────────────────────────
// Graceful shutdown
// ─────────────────────────────────────────────────────────────────────────────

async function shutdown(signal) {
  logger.info(`[Shutdown] ${signal} received — shutting down gracefully…`)
  server.close(() => logger.info('[Shutdown] HTTP server closed'))
  await stopWorkers()
  fabricService.disconnect()
  logger.info('[Shutdown] Done ✓')
  process.exit(0)
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT',  () => shutdown('SIGINT'))

process.on('uncaughtException', err => {
  logger.error('[FATAL] Uncaught exception', { error: err.message, stack: err.stack })
  process.exit(1)
})

process.on('unhandledRejection', reason => {
  logger.error('[FATAL] Unhandled rejection', { reason: String(reason) })
  process.exit(1)
})

// ─────────────────────────────────────────────────────────────────────────────
boot()
