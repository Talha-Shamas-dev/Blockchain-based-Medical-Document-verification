/**
 * verify.routes.js — Insurance / regulator verification routes
 *
 * RequestRecordAccess is a SUBMITTED transaction — it writes a
 * GRANTED or DENIED audit entry to the ledger regardless of outcome.
 * This is what makes it legally defensible for insurance claims.
 */

import express from 'express'
import { body, query } from 'express-validator'
import { authenticate, authorize } from '../middleware/auth.js'
import { validate }              from '../middleware/validate.js'
import { verifyLimiter }         from '../middleware/rateLimiter.js'
import fabricService from '../services/fabric.service.js'
import { enqueueVerifyAccess } from '../services/queue.service.js'

const router = express.Router()
router.use(authenticate, verifyLimiter)

// POST /api/verify/request — async (returns jobId, result via WebSocket)
router.post('/request',
  authorize('insurance'),
  body('recordID').trim().notEmpty().withMessage('recordID required'), validate,
  async (req, res, next) => {
    try {
      const jobId = await enqueueVerifyAccess({
        recordID: req.body.recordID,
        userId: req.user.username,
      })
      res.status(202).json({
        success: true,
        message: 'Verification queued — result via WebSocket (verify:complete)',
        jobId,
      })
    } catch (err) { next(err) }
  }
)

// POST /api/verify/request/sync — waits for Fabric
router.post('/request/sync',
  authorize('insurance'),
  body('recordID').trim().notEmpty(), validate,
  async (req, res, next) => {
    try {
      const result = await fabricService.requestRecordAccess(req.body.recordID)
      res.json({ success: true, ...result })
    } catch (err) { next(err) }
  }
)

// GET /api/verify/check?recordID=REC-001&requesterID=P001
// Fast boolean — evaluateTransaction, no on-chain trace
router.get('/check',
  query('recordID').trim().notEmpty(),
  query('requesterID').trim().notEmpty(), validate,
  async (req, res, next) => {
    try {
      const { recordID, requesterID } = req.query
      const result = await fabricService.verifyAccess(recordID, requesterID)
      res.json({ success: true, ...result })
    } catch (err) { next(err) }
  }
)

// POST /api/verify/integrity
// Compare a SHA-256 hash against the fileHash stored on-chain
router.post('/integrity',
  body('recordID').trim().notEmpty(),
  body('computedHash').trim().notEmpty()
    .matches(/^[a-fA-F0-9]+$/).withMessage('computedHash must be hex'),
  validate,
  async (req, res, next) => {
    try {
      const { recordID, computedHash } = req.body
      const result = await fabricService.verifyIntegrity(recordID, computedHash)
      res.json({ success: true, ...result })
    } catch (err) { next(err) }
  }
)

export default router
