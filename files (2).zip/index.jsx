import React, { useState } from 'react'
import { C } from '../../constants/theme'
import { Card, Badge, Btn, Stat, Input, Sel, Tbl, fmtD, fmtT } from '../../components'

export const PatientDashboard = ({ records, audit, role }) => {
  const mine = records.filter(r => r.patientID === role.msp)
  return (
    <div>
      <div style={{ marginBottom: '1rem' }}>
        <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 2px' }}>Welcome, {role.user}</h2>
        <p style={{ fontSize: 11, color: C.sec, margin: 0, fontFamily: 'monospace' }}>patientID: {role.msp}</p>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(120px,1fr))', gap: '0.6rem', marginBottom: '1rem' }}>
        <Stat label="My Records"     value={mine.length}                                          col={C.cyan} />
        <Stat label="Active"         value={mine.filter(r => !r.revoked).length}                  col={C.teal} />
        <Stat label="Shared With"    value={[...new Set(mine.flatMap(r => r.accessList).filter(x => x !== role.msp))].length} col={C.purple} />
        <Stat label="Audit Logs"     value={audit.length}                                         col={C.gold} />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '3fr 2fr', gap: '0.85rem' }}>
        <Card>
          <div style={{ fontWeight: 600, fontSize: 12, marginBottom: '0.85rem' }}>Recent Records</div>
          {mine.slice(0, 5).map(r => (
            <div key={r.recordID} style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '8px 0', borderBottom: `0.5px solid ${C.bd}` }}>
              <i className="ti ti-file-medical" style={{ fontSize: 16, color: C.cyan, flexShrink: 0 }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 500 }}>{r.description}</div>
                <div style={{ fontSize: 10, color: C.sec }}>{r.doctorName} · {fmtD(r.timestamp)}</div>
              </div>
              <Badge type={r.revoked ? 'revoked' : 'active'}>{r.revoked ? 'Revoked' : 'Active'}</Badge>
            </div>
          ))}
          {!mine.length && <div style={{ textAlign: 'center', padding: '1.25rem', color: C.sec, fontSize: 12 }}>No records yet.</div>}
        </Card>
        <Card>
          <div style={{ fontWeight: 600, fontSize: 12, marginBottom: '0.85rem' }}>Your Identity</div>
          <div style={{ background: 'rgba(0,0,0,0.35)', borderRadius: 8, padding: '0.6rem', fontFamily: 'monospace', fontSize: 10, color: C.purple, wordBreak: 'break-all', marginBottom: '0.75rem' }}>
            patientID: {role.msp}
          </div>
          <Badge type="active">Identity Verified ✓</Badge>
          <div style={{ fontSize: 11, color: C.sec, marginTop: '0.65rem', lineHeight: 1.6 }}>
            Your patientID is stored in each record's accessList on Hyperledger Fabric. Only you can grant or revoke who sees your records.
          </div>
        </Card>
      </div>
    </div>
  )
}

export const PatientRecords = ({ records, onRevoke, role }) => {
  const mine = records.filter(r => r.patientID === role.msp)
  const [sel, setSel] = useState(null)

  return (
    <div>
      <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 1rem' }}>My Medical Records</h2>
      <Card>
        <Tbl
          heads={['Record ID', 'Description', 'Doctor', 'Date', 'Shared With', 'Status', '']}
          rows={mine.map(r => [
            <span style={{ fontFamily: 'monospace', color: C.purple, fontSize: 11 }}>{r.recordID}</span>,
            r.description,
            <span style={{ color: C.sec }}>{r.doctorName}</span>,
            <span style={{ color: C.sec, whiteSpace: 'nowrap' }}>{fmtD(r.timestamp)}</span>,
            <span style={{ color: C.cyan, fontSize: 11 }}>{r.accessList.length} parties</span>,
            <Badge type={r.revoked ? 'revoked' : 'active'}>{r.revoked ? 'Revoked' : 'Active'}</Badge>,
            <Btn sm col={C.cyan} onClick={() => setSel(r)}>Details</Btn>,
          ])}
        />
      </Card>

      {sel && (
        <div onClick={() => setSel(null)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.78)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
          <div onClick={e => e.stopPropagation()} style={{ background: '#0B1020', border: `1px solid ${C.bd}`, borderRadius: 16, padding: '1.5rem', maxWidth: 480, width: '92%', maxHeight: '82vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <div style={{ fontWeight: 600, fontSize: 14 }}>{sel.recordID}</div>
              <button onClick={() => setSel(null)} style={{ background: 'transparent', border: 'none', color: C.sec, cursor: 'pointer', fontSize: 20 }}>×</button>
            </div>
            {[
              ['Description', sel.description], ['Doctor', sel.doctorName],
              ['Date', fmtD(sel.timestamp) + ' ' + fmtT(sel.timestamp)],
              ['Patient ID', sel.patientID],
              ['File CID (IPFS)', sel.fileCID],
              ['File Hash (SHA-256)', sel.fileHash],
            ].map(([k, v]) => (
              <div key={k} style={{ marginBottom: '0.65rem' }}>
                <div style={{ fontSize: 10, color: C.sec, marginBottom: 2 }}>{k}</div>
                <div style={{ fontSize: 11, fontFamily: k.includes('CID') || k.includes('Hash') ? 'monospace' : 'inherit', color: k.includes('CID') || k.includes('Hash') ? C.purple : C.text, wordBreak: 'break-all' }}>{v}</div>
              </div>
            ))}
            <div style={{ marginBottom: '0.75rem' }}>
              <div style={{ fontSize: 10, color: C.sec, marginBottom: 5 }}>Access List ({sel.accessList.length})</div>
              {sel.accessList.map(a => (
                <div key={a} style={{ fontSize: 10, fontFamily: 'monospace', color: C.cyan, background: 'rgba(0,200,232,0.08)', borderRadius: 5, padding: '3px 7px', marginBottom: 3 }}>{a}</div>
              ))}
            </div>
            {!sel.revoked && (
              <Btn full col={C.red} onClick={() => { onRevoke(sel.recordID); setSel(null) }}>
                <i className="ti ti-trash" style={{ fontSize: 13 }} />Revoke This Record
              </Btn>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

export const PatientAccess = ({ records, onGrant, onRevoke, role }) => {
  const mine = records.filter(r => r.patientID === role.msp && !r.revoked)
  const [recID, setRecID] = useState('')
  const [grantee, setGrantee] = useState('')

  return (
    <div>
      <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 1rem' }}>Access Control</h2>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.85rem' }}>
        <Card>
          <div style={{ fontWeight: 600, fontSize: 12, marginBottom: '0.85rem' }}>
            <i className="ti ti-circle-plus" style={{ fontSize: 13, color: C.teal, marginRight: 5 }} />Grant Access
          </div>
          <div style={{ fontSize: 11, color: C.sec, lineHeight: 1.6, marginBottom: '0.75rem', padding: '0.55rem', background: `rgba(0,245,212,0.06)`, borderRadius: 8, border: `0.5px solid ${C.teal}20` }}>
            Calls <span style={{ fontFamily: 'monospace', color: C.purple }}>GrantAccess(recordID, granteeID)</span> — permanently logged on chain.
          </div>
          <Sel label="Select Record" value={recID} onChange={setRecID} opts={[{ v: '', l: '— Select —' }, ...mine.map(r => ({ v: r.recordID, l: `${r.recordID} — ${r.description}` }))]} />
          <Input label="Grantee ID (patientID or MSP)" value={grantee} onChange={setGrantee} placeholder="InsureCo MSP  or  P002" />
          <Btn full col={C.teal} disabled={!recID || !grantee} onClick={() => { onGrant(recID, grantee); setGrantee('') }}>
            <i className="ti ti-circle-plus" style={{ fontSize: 13 }} />Grant on Blockchain
          </Btn>
        </Card>
        <Card>
          <div style={{ fontWeight: 600, fontSize: 12, marginBottom: '0.85rem' }}>
            <i className="ti ti-list" style={{ fontSize: 13, color: C.cyan, marginRight: 5 }} />Current Access
          </div>
          <div style={{ maxHeight: 280, overflowY: 'auto' }}>
            {mine.map(r => (
              <div key={r.recordID} style={{ marginBottom: '0.75rem', paddingBottom: '0.75rem', borderBottom: `0.5px solid ${C.bd}` }}>
                <div style={{ fontSize: 11, fontWeight: 500, marginBottom: 5, color: C.cyan }}>{r.recordID} · {r.description}</div>
                {r.accessList.map(a => (
                  <div key={a} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '2px 0' }}>
                    <span style={{ fontSize: 10, fontFamily: 'monospace', color: C.sec }}>{a.length > 34 ? a.slice(0, 32) + '…' : a}</span>
                    {a !== role.msp && a !== r.doctorName && (
                      <button onClick={() => onRevoke(r.recordID, a)} style={{ fontSize: 10, color: C.red, background: 'transparent', border: 'none', cursor: 'pointer', padding: '0 4px' }}>Revoke</button>
                    )}
                  </div>
                ))}
              </div>
            ))}
            {!mine.length && <div style={{ textAlign: 'center', padding: '1.25rem', color: C.sec, fontSize: 12 }}>No active records.</div>}
          </div>
        </Card>
      </div>
    </div>
  )
}

export const AuditTrail = ({ audit, title = 'Audit Trail' }) => (
  <div>
    <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 0.4rem' }}>{title}</h2>
    <p style={{ fontSize: 11, color: C.sec, margin: '0 0 1rem', lineHeight: 1.6 }}>
      Every access attempt is permanently recorded via <span style={{ fontFamily: 'monospace', color: C.purple }}>RequestRecordAccess()</span> — immutable on Hyperledger Fabric.
    </p>
    <Card>
      <Tbl
        heads={['Log ID', 'Record ID', 'Requester', 'Result', 'Date', 'Time']}
        rows={audit.map(l => [
          <span style={{ fontFamily: 'monospace', color: C.sec, fontSize: 10 }}>{l.id}</span>,
          <span style={{ fontFamily: 'monospace', color: C.purple, fontSize: 11 }}>{l.recordID}</span>,
          l.requester,
          <Badge type={l.result.toLowerCase()}>{l.result}</Badge>,
          <span style={{ color: C.sec, whiteSpace: 'nowrap' }}>{fmtD(l.timestamp)}</span>,
          <span style={{ color: C.sec, fontFamily: 'monospace', fontSize: 10 }}>{fmtT(l.timestamp)}</span>,
        ])}
        empty="No audit logs yet."
      />
    </Card>
  </div>
)
