// Design tokens — shared across all 4 role portals
export const C = {
  bg:     '#060B18',
  sb:     '#080E1C',
  card:   'rgba(255,255,255,0.04)',
  bd:     'rgba(255,255,255,0.08)',
  text:   '#EEF2FF',
  sec:    'rgba(238,242,255,0.55)',
  muted:  'rgba(238,242,255,0.38)',
  cyan:   '#00C8E8',
  purple: '#9B5DE5',
  pink:   '#E25E9E',
  teal:   '#00F5D4',
  blue:   '#4361EE',
  red:    '#FF5C8A',
  gold:   '#FFD166',
}

// Roles map to YOUR chaincode identities:
//   patient   → patientID (e.g. "P001") — second arg to CreateRecord
//   doctor    → Org1MSP, doctorName     — used as 5th arg to CreateRecord
//   lab       → Org2MSP, doctorName     — same CreateRecord function, different org
//   insurance → MSP identity granted access via GrantAccess
export const ROLES = [
  { id: 'patient',   label: 'Patient Portal',  color: C.cyan,   icon: 'ti-user',          user: 'Sarah Ali',      msp: 'P001',         desc: 'View your records and control who can access them.' },
  { id: 'doctor',    label: 'Doctor Portal',   color: C.purple, icon: 'ti-stethoscope',   user: 'Dr. Zia',        msp: 'Org1MSP',       desc: 'Create records and manage your patients.' },
  { id: 'lab',       label: 'Hospital / Lab',  color: C.gold,   icon: 'ti-microscope',    user: 'Lab Technician', msp: 'Org2MSP',       desc: 'Upload lab results and register them on-chain.' },
  { id: 'insurance', label: 'Insurance Co.',   color: C.teal,   icon: 'ti-building-bank', user: 'InsureCo Agent', msp: 'InsureCo MSP',  desc: 'Verify patient records for insurance claims.' },
]

export const NAV = {
  patient:   [
    { id: 'dashboard', label: 'Dashboard',      icon: 'ti-layout-dashboard' },
    { id: 'records',   label: 'My Records',     icon: 'ti-file-medical' },
    { id: 'access',    label: 'Access Control', icon: 'ti-lock' },
    { id: 'audit',     label: 'Audit Trail',    icon: 'ti-history' },
  ],
  doctor:    [
    { id: 'dashboard', label: 'Dashboard',      icon: 'ti-layout-dashboard' },
    { id: 'create',    label: 'Create Record',  icon: 'ti-circle-plus' },
    { id: 'patients',  label: 'Patients',       icon: 'ti-users' },
    { id: 'records',   label: 'My Records',     icon: 'ti-file-check' },
  ],
  lab:       [
    { id: 'dashboard', label: 'Dashboard',      icon: 'ti-layout-dashboard' },
    { id: 'upload',    label: 'Upload Result',  icon: 'ti-upload' },
    { id: 'reports',   label: 'My Reports',     icon: 'ti-report' },
  ],
  insurance: [
    { id: 'dashboard', label: 'Dashboard',      icon: 'ti-layout-dashboard' },
    { id: 'verify',    label: 'Verify Record',  icon: 'ti-shield-check' },
    { id: 'history',   label: 'Request History',icon: 'ti-history' },
  ],
}

// Demo patients for the Select dropdowns (doctor / lab create-record forms)
export const PATIENTS = [
  { patientID: 'P001', name: 'Sarah Ali' },
  { patientID: 'P002', name: 'Omar Khan' },
  { patientID: 'P003', name: 'Fatima Zahra' },
]

export const LAB_TYPES = [
  'CBC Lab Result', 'Urine Analysis', 'LFT Report', 'RFT Report',
  'HbA1c Result', 'Thyroid Panel', 'Lipid Profile', 'ECG Report',
  'Ultrasound Report', 'Culture & Sensitivity',
]

export const REPORT_TYPES = [
  'Blood Test Report', 'X-Ray Chest', 'MRI Scan', 'CT Scan',
  'Prescription', 'Ultrasound', 'ECG', 'Echocardiography',
]
