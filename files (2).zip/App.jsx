import React, { useState, useEffect, useCallback } from 'react'
import { C, ROLES, NAV } from './constants/theme'
import { TxModal, Toast } from './components'
import { PatientDashboard, PatientRecords, PatientAccess, AuditTrail } from './pages/patient'
import { DoctorDashboard, DoctorCreateRecord, DoctorPatients, DoctorRecords } from './pages/doctor'
import { LabDashboard, LabUpload, LabReports } from './pages/lab'
import { InsuranceDashboard, VerifyRecord } from './pages/insurance'
import * as api from './api/fabricService'

// ── Seed data for DEMO MODE — field names match your medical chaincode ───────
const SEED_RECORDS = [
  { recordID: 'REC-001', patientID: 'P001', patientName: 'Sarah Ali',    fileCID: 'QmXa1BcdEf2GhIj3Kl', fileHash: '3a7d9f2b1c4e8f6a', doctorName: 'Dr. Zia',        description: 'Blood Test Report', timestamp: '2026-06-24T11:29:12Z', accessList: ['P001', 'Dr. Zia'], revoked: false },
  { recordID: 'REC-002', patientID: 'P001', patientName: 'Sarah Ali',    fileCID: 'QmYb2CdeGh3IjJk4Lm', fileHash: '8b2e4f1a7c3d9e5f', doctorName: 'Dr. Zia',        description: 'X-Ray Chest',       timestamp: '2026-06-20T09:00:00Z', accessList: ['P001', 'Dr. Zia', 'InsureCo MSP'], revoked: false },
  { recordID: 'REC-003', patientID: 'P001', patientName: 'Sarah Ali',    fileCID: 'QmZc3DefHi4JkKl5Mn', fileHash: '5c9f7a2d8e1b4c3f', doctorName: 'Lab Technician', description: 'CBC Lab Result',    timestamp: '2026-06-15T14:00:00Z', accessList: ['P001', 'Lab Technician', 'Dr. Zia'], revoked: false },
  { recordID: 'REC-004', patientID: 'P002', patientName: 'Omar Khan',    fileCID: 'QmAd4EfgIj5KlLm6No', fileHash: '7d4a9c1f3b2e8g5h', doctorName: 'Dr. Zia',        description: 'MRI Brain Scan',    timestamp: '2026-06-18T16:00:00Z', accessList: ['P002', 'Dr. Zia'], revoked: false },
]
const SEED_AUDIT = [
  { id: 'LOG-001', recordID: 'REC-001', requester: 'InsureCo MSP', result: 'DENIED',  timestamp: '2026-06-25T10:22:00Z' },
  { id: 'LOG-002', recordID: 'REC-002', requester: 'InsureCo MSP', result: 'GRANTED', timestamp: '2026-06-24T09:15:00Z' },
]

const randTx  = () => '0x' + Math.random().toString(16).slice(2, 10) + Math.random().toString(16).slice(2, 8)
const newID   = n => 'REC-' + String(n + 1).padStart(3, '0')
const newLog  = n => 'LOG-' + String(n + 1).padStart(3, '0')

// Demo login users — used when no backend is reachable
const DEMO_LOGIN_MAP = {
  patient:   { username: 'patient-p001', msp: 'P001',          user: 'Sarah Ali' },
  doctor:    { username: 'doctor-zia',   msp: 'Org1MSP',        user: 'Dr. Zia' },
  lab:       { username: 'lab-tech',     msp: 'Org2MSP',        user: 'Lab Technician' },
  insurance: { username: 'insurer-1',    msp: 'InsureCo MSP',   user: 'InsureCo Agent' },
}

// ── Login Screen ──────────────────────────────────────────
const Login = ({ onSelect, demoMode, onToggleDemo, connError }) => (
  <div style={{ background: C.bg, minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '1.5rem', color: C.text, fontFamily: 'system-ui,sans-serif' }}>
    <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
      <div style={{ fontSize: 44, marginBottom: '0.4rem', lineHeight: 1 }}>⛓️</div>
      <h1 style={{ fontSize: 26, fontWeight: 700, margin: '0.35rem 0 0.2rem', background: `linear-gradient(135deg,${C.cyan},${C.purple},${C.pink})`, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>MedChain</h1>
      <p style={{ fontSize: 12, color: C.sec, margin: '0 0 0.6rem' }}>Hyperledger Fabric · mychannel · medical chaincode</p>
      <button onClick={onToggleDemo} style={{ fontSize: 11, color: demoMode ? C.gold : C.teal, background: demoMode ? `${C.gold}14` : `${C.teal}14`, border: `0.5px solid ${demoMode ? C.gold : C.teal}40`, borderRadius: 20, padding: '4px 14px', cursor: 'pointer', fontFamily: 'inherit' }}>
        {demoMode ? '🟡 Demo Mode (click to try live backend)' : '🟢 Live Mode (click to use demo data)'}
      </button>
      {connError && !demoMode && (
        <div style={{ marginTop: '0.6rem', fontSize: 11, color: C.red, maxWidth: 360 }}>
          Backend unreachable: {connError}. Falling back to demo mode is recommended.
        </div>
      )}
    </div>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', maxWidth: 540, width: '100%' }}>
      {ROLES.map(r => (
        <div key={r.id} onClick={() => onSelect(r)}
          style={{ background: 'rgba(255,255,255,0.04)', border: `1px solid ${r.color}22`, borderRadius: 14, padding: '1.1rem', cursor: 'pointer' }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = `${r.color}55`; e.currentTarget.style.background = 'rgba(255,255,255,0.06)' }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = `${r.color}22`; e.currentTarget.style.background = 'rgba(255,255,255,0.04)' }}>
          <i className={`ti ${r.icon}`} style={{ fontSize: 24, color: r.color, display: 'block', marginBottom: '0.5rem' }} />
          <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 3, color: r.color }}>{r.label}</div>
          <div style={{ fontSize: 11, color: C.sec, lineHeight: 1.5 }}>{r.desc}</div>
          <div style={{ marginTop: '0.6rem', fontSize: 10, color: C.sec }}>Login as <span style={{ color: r.color }}>{r.user}</span></div>
        </div>
      ))}
    </div>
    <p style={{ marginTop: '1.25rem', fontSize: 10, color: C.sec, opacity: 0.7 }}>
      Live mode password for all demo accounts: <span style={{ fontFamily: 'monospace' }}>medchain2025</span>
    </p>
  </div>
)

// ── Sidebar / TopBar ──────────────────────────────────────
const Sidebar = ({ role, page, onNavigate, onLogout, wsConnected, demoMode }) => {
  const nav = NAV[role.id] || []
  return (
    <div style={{ width: 200, background: '#080E1C', borderRight: `0.5px solid ${C.bd}`, display: 'flex', flexDirection: 'column', height: '100vh', position: 'sticky', top: 0, flexShrink: 0 }}>
      <div style={{ padding: '0.9rem', borderBottom: `0.5px solid ${C.bd}` }}>
        <div style={{ fontWeight: 700, fontSize: 15, color: role.color }}>⛓️ MedChain</div>
        <div style={{ fontSize: 10, color: C.sec, marginTop: 1, fontFamily: 'monospace' }}>mychannel · medical</div>
      </div>
      <div style={{ padding: '0.7rem 0.8rem', borderBottom: `0.5px solid ${C.bd}` }}>
        <div style={{ fontSize: 9, color: C.sec, textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 3 }}>Logged in as</div>
        <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 2 }}>{role.user}</div>
        <div style={{ fontSize: 9, color: role.color, fontFamily: 'monospace', wordBreak: 'break-all' }}>{role.msp}</div>
        <div style={{ marginTop: 6, display: 'flex', gap: 5, alignItems: 'center' }}>
          <span style={{ width: 5, height: 5, borderRadius: '50%', background: demoMode ? C.gold : (wsConnected ? C.teal : C.red) }} />
          <span style={{ fontSize: 9, color: C.sec }}>{demoMode ? 'Demo data' : (wsConnected ? 'Live · WS connected' : 'Live · WS offline')}</span>
        </div>
      </div>
      <nav style={{ flex: 1, padding: '0.4rem' }}>
        {nav.map(n => (
          <div key={n.id} onClick={() => onNavigate(n.id)} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 9px', borderRadius: 8, marginBottom: 2, cursor: 'pointer', fontSize: 12, background: page === n.id ? `${role.color}18` : 'transparent', color: page === n.id ? role.color : C.sec, fontWeight: page === n.id ? 600 : 400 }}>
            <i className={`ti ${n.icon}`} style={{ fontSize: 14, flexShrink: 0 }} />{n.label}
          </div>
        ))}
      </nav>
      <div style={{ padding: '0.4rem', borderTop: `0.5px solid ${C.bd}` }}>
        <div onClick={onLogout} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 9px', borderRadius: 8, cursor: 'pointer', fontSize: 12, color: C.sec }}>
          <i className="ti ti-logout" style={{ fontSize: 14 }} />Switch Role
        </div>
      </div>
    </div>
  )
}

const TopBar = ({ role, page }) => {
  const n = (NAV[role.id] || []).find(x => x.id === page)
  return (
    <div style={{ height: 48, borderBottom: `0.5px solid ${C.bd}`, display: 'flex', alignItems: 'center', padding: '0 1.1rem', gap: 9 }}>
      {n && <i className={`ti ${n.icon}`} style={{ fontSize: 14, color: role.color }} />}
      <span style={{ fontWeight: 500, fontSize: 13 }}>{n?.label || 'Dashboard'}</span>
      <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ fontSize: 10, color: C.sec, fontFamily: 'monospace' }}>mychannel</span>
      </div>
    </div>
  )
}

// ── Root App ──────────────────────────────────────────────
export default function App() {
  const [demoMode, setDemoMode] = useState(true)
  const [connError, setConnError] = useState(null)

  const [role,    setRole]    = useState(null)
  const [page,    setPage]    = useState('dashboard')
  const [records, setRecords] = useState(SEED_RECORDS)
  const [audit,   setAudit]   = useState(SEED_AUDIT)
  const [tx,      setTx]      = useState(null)
  const [loading, setLoading] = useState(false)
  const [wsConnected, setWsConnected] = useState(false)
  const [toasts, setToasts]   = useState([])

  // Check backend reachability on mount (non-blocking, used only to suggest demo/live)
  useEffect(() => {
    api.healthCheck().then(() => setConnError(null)).catch(e => setConnError(e.message))
  }, [])

  const pushToast = (title, body, error = false) => {
    const id = Date.now()
    setToasts(t => [...t, { id, title, body, error }])
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 4500)
  }

  // ── WebSocket — live mode only ───────────────────────────
  useEffect(() => {
    if (demoMode || !role) return
    const onEvent = (event, data) => {
      if (event === 'connected') setWsConnected(true)
      if (event === 'tx:confirmed') {
        pushToast('Transaction confirmed', `${data.name} · ${data.result?.recordID || ''}`)
        refreshLive()
      }
      if (event === 'verify:complete') {
        pushToast('Verification complete', data.result?.result || '')
        setAudit(a => [{ id: newLog(a.length), recordID: data.result?.record?.recordID || '—', requester: 'InsureCo MSP', result: data.result?.result, timestamp: new Date().toISOString() }, ...a])
      }
    }
    const socket = api.connectSocket(onEvent)
    return () => { api.disconnectSocket(); setWsConnected(false) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [demoMode, role])

  const refreshLive = useCallback(async () => {
    if (demoMode || !role) return
    try {
      const patientID = role.id === 'patient' ? role.msp : null
      if (patientID) {
        const res = await api.getRecordsByPatient(patientID)
        if (res.records?.length) setRecords(res.records)
      }
    } catch { /* non-fatal */ }
  }, [demoMode, role])

  // ── Login ─────────────────────────────────────────────────
  const handleLogin = async (selectedRole) => {
    if (demoMode) {
      setRole(selectedRole); setPage('dashboard')
      return
    }
    try {
      const demoUser = DEMO_LOGIN_MAP[selectedRole.id]
      const res = await api.login(demoUser.username, 'medchain2025')
      setRole({ ...selectedRole, user: res.user.name, msp: res.user.msp })
      setPage('dashboard')
      pushToast('Logged in', `${res.user.name} (${res.user.role})`)
    } catch (err) {
      pushToast('Login failed', err.message, true)
      // graceful fallback to demo for this session
      setDemoMode(true)
      setRole(selectedRole); setPage('dashboard')
    }
  }

  // ── Transaction wrapper — demo (simulated) or live (real API) ─────────────
  const fireTx = async (label, demoFn, liveFn) => {
    setLoading(true); setTx({ loading: true })
    try {
      if (demoMode) {
        await new Promise(r => setTimeout(r, 1400))
        demoFn()
        setTx({ loading: false, txId: randTx() })
      } else {
        const result = await liveFn()
        demoFn(result) // also update local state optimistically using the real result
        setTx({ loading: false, txId: result?.txId || result?.recordID || randTx() })
      }
    } catch (err) {
      setTx({ loading: false, error: err.message })
    } finally {
      setLoading(false)
    }
  }

  const handleCreate = (form) => fireTx(
    'CreateRecord',
    (liveResult) => {
      const recordID = liveResult?.recordID || newID(records.length)
      setRecords(rs => [...rs, {
        recordID, patientID: form.patientID,
        patientName: form.patientID,
        fileCID: form.fileCID, fileHash: form.fileHash,
        doctorName: form.doctorName, description: form.description,
        timestamp: new Date().toISOString(),
        accessList: [form.patientID, form.doctorName],
        revoked: false,
      }])
    },
    () => api.createRecordSync(form)
  )

  const handleGrant = (recID, grantee) => fireTx(
    'GrantAccess',
    () => setRecords(rs => rs.map(r => r.recordID === recID ? { ...r, accessList: r.accessList.includes(grantee) ? r.accessList : [...r.accessList, grantee] } : r)),
    () => api.grantAccessSync(recID, grantee)
  )

  const handleRevoke = (recID, grantee) => fireTx(
    grantee ? 'RevokeAccess' : 'RevokeRecord',
    () => {
      if (grantee) setRecords(rs => rs.map(r => r.recordID === recID ? { ...r, accessList: r.accessList.filter(a => a !== grantee) } : r))
      else setRecords(rs => rs.map(r => r.recordID === recID ? { ...r, revoked: true } : r))
    },
    () => grantee ? api.revokeAccess(recID, grantee) : api.revokeRecord(recID)
  )

  const handleVerify = (recID, ok) => fireTx(
    'RequestRecordAccess',
    (liveResult) => {
      const granted = liveResult ? liveResult.result === 'GRANTED' : ok
      setAudit(al => [{ id: newLog(al.length), recordID: recID, requester: 'InsureCo MSP', result: granted ? 'GRANTED' : 'DENIED', timestamp: new Date().toISOString() }, ...al])
    },
    () => api.requestRecordAccessSync(recID)
  )

  if (!role) return <Login onSelect={handleLogin} demoMode={demoMode} onToggleDemo={() => setDemoMode(m => !m)} connError={connError} />

  const PAGE_MAP = {
    patient: {
      dashboard: <PatientDashboard records={records} audit={audit} role={role} />,
      records:   <PatientRecords   records={records} onRevoke={id => handleRevoke(id, null)} role={role} />,
      access:    <PatientAccess    records={records} onGrant={handleGrant} onRevoke={handleRevoke} role={role} />,
      audit:     <AuditTrail audit={audit} />,
    },
    doctor: {
      dashboard: <DoctorDashboard    records={records} role={role} />,
      create:    <DoctorCreateRecord onSubmit={handleCreate} loading={loading} doctorName={role.user} />,
      patients:  <DoctorPatients     records={records} />,
      records:   <DoctorRecords      records={records} role={role} />,
    },
    lab: {
      dashboard: <LabDashboard records={records} role={role} />,
      upload:    <LabUpload    onSubmit={handleCreate} loading={loading} doctorName={role.user} demoMode={demoMode} />,
      reports:   <LabReports   records={records} role={role} />,
    },
    insurance: {
      dashboard: <InsuranceDashboard audit={audit} />,
      verify:    <VerifyRecord records={records} onVerify={handleVerify} loading={loading} />,
      history:   <AuditTrail audit={audit} title="Verification Request History" />,
    },
  }

  return (
    <div style={{ display: 'flex', background: C.bg, minHeight: '100vh', color: C.text, fontFamily: 'system-ui,-apple-system,sans-serif', fontSize: 13 }}>
      <Sidebar role={role} page={page} onNavigate={setPage} onLogout={() => { setRole(null); setPage('dashboard') }} wsConnected={wsConnected} demoMode={demoMode} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
        <TopBar role={role} page={page} />
        <div style={{ flex: 1, overflowY: 'auto', padding: '1.1rem' }}>
          {PAGE_MAP[role.id]?.[page] || <div style={{ textAlign: 'center', padding: '2rem', color: C.sec }}>Page not found.</div>}
        </div>
      </div>
      <TxModal state={tx} onClose={() => setTx(null)} />
      <Toast messages={toasts} />
    </div>
  )
}
