import React, { useState } from 'react'
import { C, PATIENTS, LAB_TYPES } from '../../constants/theme'
import { Card, Badge, Btn, Stat, Sel, Tbl, fmtD, short } from '../../components'
import { uploadToIPFS } from '../../api/fabricService'

export const LabDashboard = ({ records, role }) => {
  const mine = records.filter(r => r.doctorName === role.user)
  return (
    <div>
      <div style={{ marginBottom: '1rem' }}>
        <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 2px' }}>Hospital / Lab Dashboard</h2>
        <p style={{ fontSize: 11, color: C.sec, margin: 0 }}>{role.user} · {role.msp}</p>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(120px,1fr))', gap: '0.6rem', marginBottom: '1rem' }}>
        <Stat label="Results Uploaded" value={mine.length}                                       col={C.gold}   />
        <Stat label="Patients Served"  value={[...new Set(mine.map(r => r.patientID))].length}   col={C.cyan}   />
        <Stat label="Active"           value={mine.filter(r => !r.revoked).length}               col={C.teal}   />
        <Stat label="Org"              value={role.msp}                                          col={C.purple} />
      </div>
      <Card>
        <div style={{ fontWeight: 600, fontSize: 12, marginBottom: '0.85rem' }}>Uploaded Lab Results</div>
        {mine.map(r => (
          <div key={r.recordID} style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '8px 0', borderBottom: `0.5px solid ${C.bd}` }}>
            <i className="ti ti-microscope" style={{ fontSize: 16, color: C.gold, flexShrink: 0 }} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, fontWeight: 500 }}>{r.description} — {r.recordID}</div>
              <div style={{ fontSize: 10, color: C.sec }}>{r.patientName || r.patientID} · {fmtD(r.timestamp)}</div>
            </div>
            <Badge type={r.revoked ? 'revoked' : 'active'}>{r.revoked ? 'Revoked' : 'Active'}</Badge>
          </div>
        ))}
        {!mine.length && <div style={{ textAlign: 'center', padding: '1.25rem', color: C.sec, fontSize: 12 }}>No results uploaded yet.</div>}
      </Card>
    </div>
  )
}

export const LabUpload = ({ onSubmit, loading, doctorName, demoMode }) => {
  const [form, setForm]     = useState({ patientID: '', description: '', doctorName: doctorName || 'Lab Technician', fileCID: '', fileHash: '' })
  const [file, setFile]     = useState(null)
  const [simState, setSim]  = useState('idle') // idle | busy | done | error
  const [errMsg, setErrMsg] = useState('')
  const upd = k => v => setForm(p => ({ ...p, [k]: v }))

  const doUpload = async () => {
    setSim('busy'); setErrMsg('')
    try {
      if (demoMode || !file) {
        // Simulated upload — no real backend/file required
        await new Promise(r => setTimeout(r, 1200))
        const cid  = 'Qm' + Math.random().toString(36).slice(2, 22).toUpperCase()
        const hash = Array.from({ length: 20 }, () => Math.floor(Math.random() * 16).toString(16)).join('')
        setForm(p => ({ ...p, fileCID: cid, fileHash: hash }))
      } else {
        // Real upload to backend → Pinata IPFS
        const res = await uploadToIPFS(file)
        setForm(p => ({ ...p, fileCID: res.fileCID, fileHash: res.fileHash }))
      }
      setSim('done')
    } catch (err) {
      setSim('error'); setErrMsg(err.message)
    }
  }

  const valid = form.patientID && form.description && form.fileCID && form.fileHash

  return (
    <div>
      <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 1rem' }}>Upload Lab Result</h2>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.85rem' }}>

        <Card>
          <div style={{ fontWeight: 600, fontSize: 12, marginBottom: '0.75rem' }}>
            <span style={{ background: `${C.gold}18`, color: C.gold, borderRadius: 4, padding: '1px 6px', fontSize: 10, marginRight: 6 }}>STEP 1</span>
            File Upload → IPFS
          </div>
          <label style={{ display: 'block', border: `2px dashed ${C.bd}`, borderRadius: 10, padding: '1.25rem', textAlign: 'center', marginBottom: '0.75rem', background: 'rgba(255,255,255,0.02)', cursor: 'pointer' }}>
            <input type="file" accept=".pdf,.png,.jpg,.jpeg,.dcm" style={{ display: 'none' }}
              onChange={e => setFile(e.target.files?.[0] || null)} />
            <i className="ti ti-upload" style={{ fontSize: 26, color: C.gold, display: 'block', marginBottom: '0.4rem' }} />
            <div style={{ fontSize: 12, color: C.sec }}>{file ? file.name : 'Click to select lab result file'}</div>
            <div style={{ fontSize: 10, color: C.sec, marginTop: 3 }}>PDF / PNG / JPEG — AES-256 encrypted before IPFS upload</div>
          </label>
          <Btn full col={C.gold} loading={simState === 'busy'} onClick={doUpload}>
            <i className="ti ti-lock" style={{ fontSize: 13 }} />
            {simState === 'busy' ? 'Encrypting & uploading…' : 'Encrypt → Upload to IPFS'}
          </Btn>
          {simState === 'error' && <div style={{ marginTop: '0.6rem', fontSize: 11, color: C.red }}>{errMsg}</div>}
          {simState === 'done' && form.fileCID && (
            <div style={{ marginTop: '0.75rem', background: 'rgba(0,0,0,0.3)', borderRadius: 8, padding: '0.65rem' }}>
              <div style={{ fontSize: 10, color: C.teal, marginBottom: 4, fontWeight: 600 }}>✓ File uploaded to IPFS</div>
              <div style={{ fontSize: 9, color: C.sec }}>fileCID:</div>
              <div style={{ fontSize: 10, fontFamily: 'monospace', color: C.purple, wordBreak: 'break-all', marginBottom: 5 }}>{form.fileCID}</div>
              <div style={{ fontSize: 9, color: C.sec }}>fileHash:</div>
              <div style={{ fontSize: 10, fontFamily: 'monospace', color: C.teal, wordBreak: 'break-all' }}>{form.fileHash}</div>
            </div>
          )}
        </Card>

        <Card>
          <div style={{ fontWeight: 600, fontSize: 12, marginBottom: '0.75rem' }}>
            <span style={{ background: `${C.purple}18`, color: C.purple, borderRadius: 4, padding: '1px 6px', fontSize: 10, marginRight: 6 }}>STEP 2</span>
            Register on Blockchain
          </div>
          <Sel label="Patient" value={form.patientID} onChange={upd('patientID')}
            opts={[{ v: '', l: '— Select Patient —' }, ...PATIENTS.map(p => ({ v: p.patientID, l: `${p.name} (${p.patientID})` }))]} />
          <Sel label="Test Type" value={form.description} onChange={upd('description')}
            opts={[{ v: '', l: '— Select Test —' }, ...LAB_TYPES.map(t => ({ v: t, l: t }))]} />
          <div style={{ fontSize: 10, color: C.sec, marginBottom: '0.75rem' }}>
            fileCID: <span style={{ fontFamily: 'monospace', color: form.fileCID ? C.purple : C.sec }}>{form.fileCID || 'Auto-filled after Step 1'}</span>
          </div>
          <Btn full col={C.gold} disabled={!valid} loading={loading} onClick={() => onSubmit(form)}>
            <i className="ti ti-link" style={{ fontSize: 13 }} />CreateRecord on Fabric
          </Btn>
          <div style={{ marginTop: '0.75rem', fontSize: 10, color: C.sec, lineHeight: 1.6, padding: '0.55rem', background: `rgba(255,209,102,0.06)`, borderRadius: 7, border: `0.5px solid ${C.gold}20` }}>
            fileCID + fileHash stored permanently via <span style={{ fontFamily: 'monospace' }}>CreateRecord()</span>. Patient auto-added to accessList.
          </div>
        </Card>
      </div>
    </div>
  )
}

export const LabReports = ({ records, role }) => {
  const mine = records.filter(r => r.doctorName === role.user)
  return (
    <div>
      <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 1rem' }}>My Lab Reports</h2>
      <Card>
        <Tbl
          heads={['Record ID', 'Patient', 'Test Type', 'File CID', 'Date', 'Status']}
          rows={mine.map(r => [
            <span style={{ fontFamily: 'monospace', color: C.purple, fontSize: 11 }}>{r.recordID}</span>,
            r.patientName || r.patientID, r.description,
            <span style={{ fontFamily: 'monospace', fontSize: 10, color: C.sec }}>{short(r.fileCID)}</span>,
            <span style={{ color: C.sec, whiteSpace: 'nowrap' }}>{fmtD(r.timestamp)}</span>,
            <Badge type={r.revoked ? 'revoked' : 'active'}>{r.revoked ? 'Revoked' : 'Active'}</Badge>,
          ])}
        />
      </Card>
    </div>
  )
}
