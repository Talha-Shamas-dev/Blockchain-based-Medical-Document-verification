import React, { useState } from 'react'
import { C, PATIENTS, REPORT_TYPES } from '../../constants/theme'
import { Card, Badge, Btn, Stat, Input, Sel, Tbl, fmtD, short } from '../../components'

export const DoctorDashboard = ({ records, role }) => {
  const mine = records.filter(r => r.doctorName === role.user)
  return (
    <div>
      <div style={{ marginBottom: '1rem' }}>
        <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 2px' }}>Doctor Dashboard</h2>
        <p style={{ fontSize: 11, color: C.sec, margin: 0 }}>{role.user} · {role.msp}</p>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(120px,1fr))', gap: '0.6rem', marginBottom: '1rem' }}>
        <Stat label="Records Created" value={mine.length}                              col={C.purple} />
        <Stat label="Patients"        value={[...new Set(mine.map(r => r.patientID))].length} col={C.cyan} />
        <Stat label="Active"          value={mine.filter(r => !r.revoked).length}      col={C.teal}   />
        <Stat label="Org"             value={role.msp}                                 col={C.pink}   />
      </div>
      <Card>
        <div style={{ fontWeight: 600, fontSize: 12, marginBottom: '0.85rem' }}>Records You Created</div>
        {mine.map(r => (
          <div key={r.recordID} style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '8px 0', borderBottom: `0.5px solid ${C.bd}` }}>
            <i className="ti ti-file-medical" style={{ fontSize: 16, color: C.purple, flexShrink: 0 }} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, fontWeight: 500 }}>{r.description} — {r.recordID}</div>
              <div style={{ fontSize: 10, color: C.sec }}>{r.patientName || r.patientID} · {fmtD(r.timestamp)}</div>
            </div>
            <span style={{ fontSize: 10, fontFamily: 'monospace', color: C.sec, flexShrink: 0 }}>{short(r.fileCID)}</span>
          </div>
        ))}
        {!mine.length && <div style={{ textAlign: 'center', padding: '1.25rem', color: C.sec, fontSize: 12 }}>No records created yet.</div>}
      </Card>
    </div>
  )
}

export const DoctorCreateRecord = ({ onSubmit, loading, doctorName }) => {
  const [form, setForm] = useState({ patientID: '', fileCID: '', fileHash: '', doctorName: doctorName || '', description: '' })
  const upd = k => v => setForm(p => ({ ...p, [k]: v }))
  const valid = form.patientID && form.fileCID && form.fileHash && form.doctorName && form.description

  return (
    <div>
      <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 1rem' }}>Create Medical Record</h2>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.85rem' }}>
        <Card>
          <div style={{ fontWeight: 600, fontSize: 12, marginBottom: '0.75rem' }}>Record Details</div>
          <Sel label="Patient" value={form.patientID} onChange={upd('patientID')}
            opts={[{ v: '', l: '— Select Patient —' }, ...PATIENTS.map(p => ({ v: p.patientID, l: `${p.name} (${p.patientID})` }))]} />
          <Sel label="Description" value={form.description} onChange={upd('description')}
            opts={[{ v: '', l: '— Select Type —' }, ...REPORT_TYPES.map(t => ({ v: t, l: t }))]} />
          <Input label="Doctor Name" value={form.doctorName} onChange={upd('doctorName')} placeholder="Dr. Zia" />
          <Input label="File CID (after IPFS upload)" value={form.fileCID} onChange={upd('fileCID')} placeholder="QmXa1BcdEf2GhIj3..." mono />
          <Input label="File Hash (SHA-256)" value={form.fileHash} onChange={upd('fileHash')} placeholder="3a7d9f2b1c4e8f6a..." mono />
          <div style={{ fontSize: 10, color: C.sec, marginBottom: '0.75rem', lineHeight: 1.6, padding: '0.55rem', background: 'rgba(155,93,229,0.06)', borderRadius: 7, border: `0.5px solid ${C.purple}20` }}>
            Calls <span style={{ fontFamily: 'monospace' }}>CreateRecord(recordID, patientID, fileCID, fileHash, doctorName, description)</span>. Patient auto-added to accessList.
          </div>
          <Btn full col={C.purple} disabled={!valid} loading={loading} onClick={() => onSubmit(form)}>
            <i className="ti ti-link" style={{ fontSize: 13 }} />Submit to Hyperledger Fabric
          </Btn>
        </Card>
        <Card>
          <div style={{ fontWeight: 600, fontSize: 12, marginBottom: '0.85rem' }}>What happens on submit</div>
          {[
            [C.cyan,   'ti-check',    'Validation',     'API checks all 6 fields are present'],
            [C.pink,   'ti-world',    'IPFS Reference',  'fileCID points to your AES-256 encrypted file'],
            [C.purple, 'ti-link',     'CreateRecord()',  'Chaincode invoked on mychannel'],
            [C.teal,   'ti-check',    'Consensus',       'Orderer + both peers finalize the block'],
            [C.blue,   'ti-database', 'Ledger Write',    'Record permanently stored on Fabric'],
          ].map(([col, icon, title, desc]) => (
            <div key={title} style={{ display: 'flex', gap: 9, marginBottom: '0.65rem', alignItems: 'flex-start' }}>
              <i className={`ti ${icon}`} style={{ fontSize: 15, color: col, flexShrink: 0, marginTop: 2 }} />
              <div>
                <div style={{ fontSize: 12, fontWeight: 500 }}>{title}</div>
                <div style={{ fontSize: 10, color: C.sec }}>{desc}</div>
              </div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  )
}

export const DoctorPatients = ({ records }) => (
  <div>
    <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 1rem' }}>Patients</h2>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))', gap: '0.75rem' }}>
      {PATIENTS.map(p => {
        const recs = records.filter(r => r.patientID === p.patientID)
        return (
          <Card key={p.patientID}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: '0.75rem' }}>
              <div style={{ width: 36, height: 36, borderRadius: '50%', background: `${C.purple}18`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <i className="ti ti-user" style={{ fontSize: 17, color: C.purple }} />
              </div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{p.name}</div>
                <div style={{ fontSize: 9, fontFamily: 'monospace', color: C.sec }}>{p.patientID}</div>
              </div>
            </div>
            <div style={{ fontSize: 11, color: C.sec, marginBottom: '0.5rem' }}>
              Records on chain: <span style={{ color: C.cyan, fontWeight: 600 }}>{recs.length}</span>
            </div>
            <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
              {recs.map(r => <Badge key={r.recordID} type="info">{r.description.split(' ')[0]}</Badge>)}
              {!recs.length && <span style={{ fontSize: 10, color: C.sec }}>No records yet</span>}
            </div>
          </Card>
        )
      })}
    </div>
  </div>
)

export const DoctorRecords = ({ records, role }) => {
  const mine = records.filter(r => r.doctorName === role.user)
  return (
    <div>
      <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 1rem' }}>Records Created by You</h2>
      <Card>
        <Tbl
          heads={['Record ID', 'Patient ID', 'Description', 'File CID', 'Date', 'Status']}
          rows={mine.map(r => [
            <span style={{ fontFamily: 'monospace', color: C.purple, fontSize: 11 }}>{r.recordID}</span>,
            r.patientName || r.patientID,
            r.description,
            <span style={{ fontFamily: 'monospace', fontSize: 10, color: C.sec }}>{short(r.fileCID)}</span>,
            <span style={{ color: C.sec, whiteSpace: 'nowrap' }}>{fmtD(r.timestamp)}</span>,
            <Badge type={r.revoked ? 'revoked' : 'active'}>{r.revoked ? 'Revoked' : 'Active'}</Badge>,
          ])}
        />
      </Card>
    </div>
  )
}
