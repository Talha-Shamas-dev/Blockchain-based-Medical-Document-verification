import React, { useState } from 'react'
import { C } from '../../constants/theme'
import { Card, Badge, Btn, Stat, Sel, fmtD } from '../../components'
import { AuditTrail } from '../patient'

export const InsuranceDashboard = ({ audit }) => {
  const g = audit.filter(l => l.result === 'GRANTED').length
  const d = audit.filter(l => l.result === 'DENIED').length
  return (
    <div>
      <div style={{ marginBottom: '1rem' }}>
        <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 2px' }}>Insurance Company Dashboard</h2>
        <p style={{ fontSize: 11, color: C.sec, margin: 0 }}>InsureCo MSP · All verification requests are permanently logged on Hyperledger Fabric</p>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(120px,1fr))', gap: '0.6rem', marginBottom: '1rem' }}>
        <Stat label="Total Requests" value={audit.length}                                            col={C.teal}   />
        <Stat label="Granted"        value={g}                                                       col={C.teal}   sub="Access provided" />
        <Stat label="Denied"         value={d}                                                       col={C.red}    />
        <Stat label="Grant Rate"     value={audit.length ? Math.round(g / audit.length * 100) + '%' : '—'} col={C.purple} />
      </div>
      <AuditTrail audit={audit.slice(0, 10)} title="Recent Verification Requests" />
    </div>
  )
}

export const VerifyRecord = ({ records, onVerify, loading }) => {
  const [recID, setRecID]   = useState('')
  const [result, setResult] = useState(null)

  const doVerify = async () => {
    const rec = records.find(r => r.recordID === recID)
    const granted = !!(rec && !rec.revoked && rec.accessList.includes('InsureCo MSP'))
    setResult({ rec, granted })
    onVerify(recID, granted)
  }

  return (
    <div>
      <h2 style={{ fontSize: 17, fontWeight: 600, margin: '0 0 1rem' }}>Verify Medical Record</h2>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.85rem' }}>
        <Card>
          <div style={{ fontWeight: 600, fontSize: 12, marginBottom: '0.65rem' }}>Request Verification</div>
          <div style={{ fontSize: 11, color: C.sec, lineHeight: 1.6, padding: '0.6rem', background: 'rgba(0,245,212,0.05)', border: `0.5px solid ${C.teal}25`, borderRadius: 8, marginBottom: '0.75rem' }}>
            Calls <span style={{ fontFamily: 'monospace', color: C.purple }}>RequestRecordAccess(recordID)</span> — a <strong style={{ color: C.text }}>submitted transaction</strong>. Whether granted or denied, this becomes a permanent ledger entry.
          </div>
          <Sel label="Select Record ID" value={recID} onChange={setRecID}
            opts={[{ v: '', l: '— Select Record —' }, ...records.map(r => ({ v: r.recordID, l: `${r.recordID} — ${r.description} (${r.patientName || r.patientID})` }))]} />
          <div style={{ fontSize: 10, color: C.sec, marginBottom: '0.75rem' }}>
            Your identity: <span style={{ fontFamily: 'monospace', color: C.teal }}>InsureCo MSP</span>
          </div>
          <Btn full col={C.teal} disabled={!recID} loading={loading} onClick={doVerify}>
            <i className="ti ti-shield-check" style={{ fontSize: 13 }} />Request Verification
          </Btn>
        </Card>

        {result ? (
          <Card glow={result.granted ? `${C.teal}55` : `${C.red}55`}>
            <div style={{ textAlign: 'center', padding: '0.5rem 0' }}>
              <div style={{ fontSize: 44, marginBottom: '0.5rem' }}>{result.granted ? '✅' : '❌'}</div>
              <Badge type={result.granted ? 'granted' : 'denied'}>{result.granted ? 'ACCESS GRANTED' : 'ACCESS DENIED'}</Badge>
              {result.granted && result.rec && (
                <div style={{ marginTop: '1rem', textAlign: 'left' }}>
                  {[
                    ['Description', result.rec.description],
                    ['Patient ID',  result.rec.patientID],
                    ['Doctor',      result.rec.doctorName],
                    ['Date',        fmtD(result.rec.timestamp)],
                    ['File CID',    result.rec.fileCID],
                    ['File Hash',   result.rec.fileHash],
                  ].map(([k, v]) => (
                    <div key={k} style={{ marginBottom: '0.5rem' }}>
                      <div style={{ fontSize: 9, color: C.sec }}>{k}</div>
                      <div style={{ fontSize: 11, fontFamily: k.includes('CID') || k.includes('Hash') ? 'monospace' : 'inherit', color: k.includes('CID') || k.includes('Hash') ? C.purple : C.text, wordBreak: 'break-all' }}>{v}</div>
                    </div>
                  ))}
                </div>
              )}
              {!result.granted && (
                <p style={{ fontSize: 11, color: C.sec, marginTop: '0.75rem', lineHeight: 1.6 }}>
                  Patient has not granted InsureCo MSP access to this record, or the record has been revoked.
                </p>
              )}
              <div style={{ marginTop: '0.75rem', fontSize: 9, color: C.sec, fontFamily: 'monospace' }}>Request logged on-chain ✓</div>
            </div>
          </Card>
        ) : (
          <Card>
            <div style={{ textAlign: 'center', padding: '2rem', color: C.sec, fontSize: 12 }}>
              <i className="ti ti-shield" style={{ fontSize: 28, color: C.bd, display: 'block', marginBottom: '0.65rem' }} />
              Select a record and click Verify
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
